id: file://<WORKSPACE>/helloworld.scala:[4..5) in Input.VirtualFile("file://<WORKSPACE>/helloworld.scala", "def @main:
    print("Helloworl")")
file://<WORKSPACE>/helloworld.scala
file://<WORKSPACE>/helloworld.scala:1: error: expected identifier; obtained at
def @main:
    ^
#### Short summary: 

expected identifier; obtained at