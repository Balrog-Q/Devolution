id: file://<WORKSPACE>/helloworld.scala:[6..7) in Input.VirtualFile("file://<WORKSPACE>/helloworld.scala", "class @main:
    print("Helloworld!")")
file://<WORKSPACE>/helloworld.scala
file://<WORKSPACE>/helloworld.scala:1: error: expected identifier; obtained at
class @main:
      ^
#### Short summary: 

expected identifier; obtained at