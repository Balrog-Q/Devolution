id: file://<WORKSPACE>/helloworld.scala:[10..11) in Input.VirtualFile("file://<WORKSPACE>/helloworld.scala", "@main def :
    print("Helloworld!")
end ")
file://<WORKSPACE>/helloworld.scala
file://<WORKSPACE>/helloworld.scala:1: error: expected identifier; obtained colon
@main def :
          ^
#### Short summary: 

expected identifier; obtained colon