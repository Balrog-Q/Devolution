package devolution.helpers

import devolution.helpers.*

/**
  * The constants that should be used everywhere go here. Mainly used for the dialogues.
  */

val D = Dialogues

val VisionUnlock = 5
val Endgame = 8